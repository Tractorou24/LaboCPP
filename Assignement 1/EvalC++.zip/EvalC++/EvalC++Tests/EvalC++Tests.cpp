#include "pch.h"
#include "CppUnitTest.h"
#include "../EvalC++/HashTable.h"

#include <stdexcept>

namespace EvalTests
{
	using namespace Microsoft::VisualStudio::CppUnitTestFramework;

	TEST_CLASS(Methods)
	{
	public:
		TEST_METHOD(Creation)
		{
			HashTable t;
			for(auto& elem : t.GetData())
				Assert::IsTrue(elem->status == HashTableStatus::NeverUsed);
		}

		TEST_METHOD(Insert)
		{
			HashTable t;
			t.Insert("abricot");
			Assert::IsTrue(t.GetData()[std::tolower('a') - 97]->status == HashTableStatus::Occupied);
			Assert::IsTrue(t.GetData()[std::tolower('a') - 97]->value == "abricot");
		}

		TEST_METHOD(InsertException)
		{
			HashTable t;
			try
			{
				for (int i = 0; i < 50; i++)
					t.Insert(std::to_string(i));
			}
			catch (const std::runtime_error& except)
			{
				Assert::IsTrue(true);
			}
			catch (const std::exception& except)
			{
				Assert::IsTrue(false);
			}
		}

		TEST_METHOD(Delete)
		{
			HashTable t;
			t.Insert("abricot");
			t.Delete("abricot");
			Assert::IsTrue(t.GetData()[std::tolower('a') - 97]->status == HashTableStatus::Tombstone);
		}

		TEST_METHOD(Search)
		{
			HashTable t;
			t.Insert("abricot");
			t.Insert("tomate");
			t.Delete("abricot");
			Assert::IsTrue(t.Search("tomate"));
			Assert::IsFalse(t.Search("abricot"));
		}

		TEST_METHOD(CAPS)
		{
			HashTable t;
			t.Insert("Abricot");
			t.Insert("TOMATE");
			t.Delete("Abricot");
			Assert::IsTrue(t.Search("TOMATE"));
			Assert::IsFalse(t.Search("Abricot"));
		}
	};

	TEST_CLASS(Operators)
	{
	public:
		TEST_METHOD(Print)
		{
			HashTable t;
			t.Insert("Saucisson");
			t.Insert("Foie Gras");
			t.Insert("Chapon");
			t.Insert("Patates");
			t.Delete("Saucisson");

			std::stringstream ss;
			ss << t;
			Assert::IsTrue(ss.str() == "Chapon Foie Gras Patates " || ss.str() == "Chapon Foie Gras Patates");
		}
	};
}
